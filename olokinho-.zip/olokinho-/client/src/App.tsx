import { lazy, Suspense } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { ErrorBoundary } from "react-error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import { ErrorFallback, RouteErrorFallback } from "@/components/ErrorFallback";
import { logError } from "@/lib/errorLogger";
import { Loader2 } from "lucide-react";

// Eager load critical pages (Landing, Login, Register)
import LandingPage from "@/pages/LandingPage";
import LoginPage from "@/pages/LoginPage";
import RegisterPage from "@/pages/RegisterPage";

// Lazy load all other pages for better performance
const ForgotPasswordPage = lazy(() => import("@/pages/ForgotPasswordPage"));
const ResetPasswordPage = lazy(() => import("@/pages/ResetPasswordPage"));
const DashboardPage = lazy(() => import("@/pages/DashboardPage"));
const CustomersPage = lazy(() => import("@/pages/CustomersPage"));
const InvoicesPage = lazy(() => import("@/pages/InvoicesPage"));
const SettingsPage = lazy(() => import("@/pages/SettingsPage"));
const TransactionsPage = lazy(() => import("@/pages/TransactionsPage"));
const ReportsPage = lazy(() => import("@/pages/ReportsPage"));
const ImportsPage = lazy(() => import("@/pages/ImportsPage"));
const ReconciliationsPage = lazy(() => import("@/pages/ReconciliationsPage"));
const ProfilePage = lazy(() => import("@/pages/ProfilePage"));
const AccountsPage = lazy(() => import("@/pages/AccountsPage"));
const CategoriesPage = lazy(() => import("@/pages/CategoriesPage"));
const CostCentersPage = lazy(() => import("@/pages/CostCentersPage"));
const BankAccountsPage = lazy(() => import("@/pages/BankAccountsPage"));
const DocumentsPage = lazy(() => import("@/pages/DocumentsPage"));
const TagsPage = lazy(() => import("@/pages/TagsPage"));
const ExportPage = lazy(() => import("@/pages/ExportPage"));
const SubscriptionPage = lazy(() => import("@/pages/SubscriptionPage"));
const PricingPage = lazy(() => import("@/pages/PricingPage"));
const RecursosPage = lazy(() => import("@/pages/RecursosPage"));
const IntegracoesPage = lazy(() => import("@/pages/IntegracoesPage"));
const APIDocsPage = lazy(() => import("@/pages/APIDocsPage"));
const SobrePage = lazy(() => import("@/pages/SobrePage"));
const BlogPage = lazy(() => import("@/pages/BlogPage"));
const CarreirasPage = lazy(() => import("@/pages/CarreirasPage"));
const ContatoPage = lazy(() => import("@/pages/ContatoPage"));
const PrivacidadePage = lazy(() => import("@/pages/PrivacidadePage"));
const TermosPage = lazy(() => import("@/pages/TermosPage"));
const SegurancaPage = lazy(() => import("@/pages/SegurancaPage"));
const LGPDPage = lazy(() => import("@/pages/LGPDPage"));
const HelpVideoaulasPage = lazy(() => import("@/pages/HelpVideoaulasPage"));
const HelpGuiasPage = lazy(() => import("@/pages/HelpGuiasPage"));
const HelpDicasPage = lazy(() => import("@/pages/HelpDicasPage"));
const HelpFeedbackPage = lazy(() => import("@/pages/HelpFeedbackPage"));
const HelpSuportePage = lazy(() => import("@/pages/HelpSuportePage"));
const NotFound = lazy(() => import("@/pages/not-found"));

// Loading fallback component
function PageLoader() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <Loader2 className="w-8 h-8 animate-spin text-primary" />
    </div>
  );
}

function RouteWrapper({ component: Component }: { component: React.ComponentType }) {
  return (
    <ErrorBoundary FallbackComponent={RouteErrorFallback} onError={logError}>
      <Suspense fallback={<PageLoader />}>
        <Component />
      </Suspense>
    </ErrorBoundary>
  );
}

function Router() {
  return (
    <Switch>
      {/* Eager loaded routes (critical paths) */}
      <Route path="/" component={LandingPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/register" component={RegisterPage} />
      
      {/* Lazy loaded routes (code-split for performance) */}
      <Route path="/forgot-password">
        <Suspense fallback={<PageLoader />}>
          <ForgotPasswordPage />
        </Suspense>
      </Route>
      <Route path="/reset-password">
        <Suspense fallback={<PageLoader />}>
          <ResetPasswordPage />
        </Suspense>
      </Route>
      <Route path="/app/dashboard">
        <RouteWrapper component={DashboardPage} />
      </Route>
      <Route path="/app/transactions">
        <RouteWrapper component={TransactionsPage} />
      </Route>
      <Route path="/app/customers">
        <RouteWrapper component={CustomersPage} />
      </Route>
      <Route path="/app/reports">
        <RouteWrapper component={ReportsPage} />
      </Route>
      <Route path="/app/imports">
        <RouteWrapper component={ImportsPage} />
      </Route>
      <Route path="/app/reconciliations">
        <RouteWrapper component={ReconciliationsPage} />
      </Route>
      <Route path="/app/invoices">
        <RouteWrapper component={InvoicesPage} />
      </Route>
      <Route path="/app/settings">
        <RouteWrapper component={SettingsPage} />
      </Route>
      <Route path="/app/profile">
        <RouteWrapper component={ProfilePage} />
      </Route>
      <Route path="/app/accounts">
        <RouteWrapper component={AccountsPage} />
      </Route>
      <Route path="/app/categories">
        <RouteWrapper component={CategoriesPage} />
      </Route>
      <Route path="/app/cost-centers">
        <RouteWrapper component={CostCentersPage} />
      </Route>
      <Route path="/app/bank-accounts">
        <RouteWrapper component={BankAccountsPage} />
      </Route>
      <Route path="/app/documents">
        <RouteWrapper component={DocumentsPage} />
      </Route>
      <Route path="/app/tags">
        <RouteWrapper component={TagsPage} />
      </Route>
      <Route path="/app/export">
        <RouteWrapper component={ExportPage} />
      </Route>
      <Route path="/app/subscription">
        <RouteWrapper component={SubscriptionPage} />
      </Route>
      <Route path="/app/pricing">
        <RouteWrapper component={PricingPage} />
      </Route>
      <Route path="/pricing">
        <RouteWrapper component={PricingPage} />
      </Route>
      <Route path="/recursos">
        <RouteWrapper component={RecursosPage} />
      </Route>
      <Route path="/integracoes">
        <RouteWrapper component={IntegracoesPage} />
      </Route>
      <Route path="/api-docs">
        <RouteWrapper component={APIDocsPage} />
      </Route>
      <Route path="/sobre">
        <RouteWrapper component={SobrePage} />
      </Route>
      <Route path="/blog">
        <RouteWrapper component={BlogPage} />
      </Route>
      <Route path="/carreiras">
        <RouteWrapper component={CarreirasPage} />
      </Route>
      <Route path="/contato">
        <RouteWrapper component={ContatoPage} />
      </Route>
      <Route path="/privacidade">
        <RouteWrapper component={PrivacidadePage} />
      </Route>
      <Route path="/termos">
        <RouteWrapper component={TermosPage} />
      </Route>
      <Route path="/seguranca">
        <RouteWrapper component={SegurancaPage} />
      </Route>
      <Route path="/lgpd">
        <RouteWrapper component={LGPDPage} />
      </Route>
      <Route path="/help/videoaulas">
        <RouteWrapper component={HelpVideoaulasPage} />
      </Route>
      <Route path="/help/guias">
        <RouteWrapper component={HelpGuiasPage} />
      </Route>
      <Route path="/help/dicas">
        <RouteWrapper component={HelpDicasPage} />
      </Route>
      <Route path="/help/feedback">
        <RouteWrapper component={HelpFeedbackPage} />
      </Route>
      <Route path="/help/suporte">
        <RouteWrapper component={HelpSuportePage} />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary FallbackComponent={ErrorFallback} onError={logError}>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
