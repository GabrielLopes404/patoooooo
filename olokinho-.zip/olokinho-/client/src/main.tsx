import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { initSentry } from "./lib/sentry";
import "./lib/i18n";

// Initialize Sentry as early as possible
initSentry();

createRoot(document.getElementById("root")!).render(<App />);
